#! /bin/bash
cd redis_conf 
mv redis_model.conf ..
 rm -rf ./* 
mv ../redis_model.conf .
cd ..
rm -rf redis_log/*
rm -rf redis_node/*
rm -rf redis_rdb/*
tree .
