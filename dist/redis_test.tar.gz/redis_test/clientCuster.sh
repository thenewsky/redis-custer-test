#!/bin/bash
#redis-cli -p 10011 -a 
redis-cli -c -p $1

