#! /bin/bash
. ./config.properties



time for i in `seq $port_begin 1 $port_end`;
do 
echo  $i;

 ./bin/redis-cli -p $i -a $passwd shutdown;
done
ps -ef |grep redis
#netstat -lnap|grep redis
