#! /bin/bash
. ./config.properties



time for i in `seq $port_begin 1 $port_end`;
do 
echo port  $i;

./bin/redis-cli -p $i -a $passwd shutdown;
#sleep 1;
#echo ./bin/redis-server  redis_conf/redis_$i.conf ;
 ./bin/redis-server  redis_conf/redis_$i.conf;


done

#netstat -lnap|grep redis-server
ps -ef |grep redis

