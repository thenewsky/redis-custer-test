#! /bin/bash


. ./config.properties


cd redis_conf


time for i in `seq $port_begin 1 $port_end`;
do 
echo  $i;

cp redis_model.conf redis_$i.conf;
sudo sed -i "s/{ip}/$ip/g" ./redis_$i.conf;
sudo sed -i "s/{port}/$i/g" ./redis_$i.conf;
sudo sed -i "s/{path_log}/$path_log/g" ./redis_$i.conf;
sudo sed -i "s/{path_rdb}/$path_rdb/g" ./redis_$i.conf;
sudo sed -i "s/{passwd}/$passwd/g" ./redis_$i.conf;
sudo sed -i "s/{path_node}/$path_node/g" ./redis_$i.conf;


done
