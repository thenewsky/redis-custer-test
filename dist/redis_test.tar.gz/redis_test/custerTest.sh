java -jar insert.jar 
