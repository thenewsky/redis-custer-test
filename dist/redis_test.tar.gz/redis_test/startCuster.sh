#! /bin/bash

. ./config.properties

value=""
time for i in `seq $port_begin 1 $port_end`;
do 
#echo  $i;
value=`echo $value " 127.0.0.1:$i"`
done
./bin/redis-trib.rb create --replicas 1 $value
