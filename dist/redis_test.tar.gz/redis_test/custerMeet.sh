#! /bin/bash
. ./config.properties



time for i in `seq $port_begin 1 $port_end`;
do 
./sshSql.sh $master1 "cluster meet 127.0.0.1 $i"

done


