#! /bin/bash


CMD=./bin/redis-cli

CONFIG11="-c -p $1"


echo $2 | $CMD $CONFIG11
